#!/bin/bash

#
#    Copyright (C) 2021 @Errors QQ:1075695713
#    2021-01-01 13:46:06 
#

LOCAL_DIR=$(pwd)						#本地目录
PROJECT_DIR=$LOCAL_DIR/${1}					#工程目录
SHELL=$(readlink -f "$0")					#脚本文件
SHELL_DIR=$(dirname $SHELL)					#脚本路径



echo "本地目录: $LOCAL_DIR"
echo "工程目录: $PROJECT_DIR"
echo "脚本文件: $SHELL"
echo "脚本路径: $SHELL_DIR"



if [[ -f ${PROJECT_DIR}/system/system/build.prop ]]; then
	SYSTEM_DIR="${PROJECT_DIR}/system/system"
elif [[ -f ${PROJECT_DIR}/system/build.prop ]]; then
	SYSTEM_DIR="${PROJECT_DIR}/system"
else
	read -p "  WRONG !"
	exit
fi



DEVICE=$(cat ${SYSTEM_DIR}/build.prop | grep "ro.product.device" | cut -d"=" -f 2)
if [[ $DEVICE = "" ]]; then
	DEVICE=$(cat ${SYSTEM_DIR}/build.prop | grep "ro.product.system.device" | cut -d"=" -f 2)
	if [[ $DEVICE = "" ]]; then
		DEVICE=$(grep ro.product.name ${SYSTEM_DIR}/build.prop | cut -d "=" -f 2)
	fi
fi


API=$(cat ${SYSTEM_DIR}/build.prop | grep "ro.build.version.release" | cut -d"=" -f 2)
if [[ $API = "" ]]; then
	API=$(cat ${SYSTEM_DIR}/build.prop | grep "ro.system.build.version.release" | cut -d"=" -f 2)
	if [[ $API = "" ]]; then
		API=$(grep ro.build.version.release_or_codename ${SYSTEM_DIR}/build.prop | cut -d "=" -f 2)
	fi
fi
if [ $(echo $API | cut -d "." -f 2) == 0 ]; then
    API=$(echo $API | cut -d "." -f 1)
fi

if [[ ${DEVICE} != "" && ${API} != "" ]]; then
	if [ -f ${SHELL_PATH}/Insides/Errors/devices/${DEVICE}/${API}/${DEVICE}.txt ]; then
		Lists="${SHELL_PATH}/Insides/Errors/devices/${DEVICE}/$API/${DEVICE}.txt"
	elif [[ $(find ${SYSTEM_DIR}/* -name miui.apk 2>/dev/null) && $(find ${SYSTEM_DIR}/* -name miuisystem.apk) ]]; then
		Lists="${SHELL_PATH}/Insides/Errors/devices/xiaomi.txt"
	else
		Lists=""
	fi
fi

if [ -f $Lists ]; then
	while read line; do
		if [ -e ${SYSTEM_DIR}/$line ]; then
			echo "rm -rf $line"
			rm -rf ${SYSTEM_DIR}/$line
		fi
	done < $Lists
else
	read -p "  Not Suppost !"
	exit
fi

echo -en "\n完成，任意键返回 ..."
read
