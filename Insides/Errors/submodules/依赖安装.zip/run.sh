#!/bin/bash

#
#    Copyright (C) 2021 @Errors QQ:1075695713
#    2021-01-01 13:46:06 
#


if [[ $(uname -m) == "aarch64" ]]; then
    su=""
else
    su="sudo "
fi


${su}apt update && sudo apt upgrade -y
${su}apt install git aria2 brotli android-sdk-libsparse-utils android-sdk-ext4-utils p7zip-full openjdk-14-jdk -y


echo -en "\n完成，任意键返回 ..."
read
