#!/bin/bash

#
#    Copyright (C) 2021 @Errors QQ:1075695713
#    2021-01-01 13:46:06 
#

LOCAL_DIR=$(pwd)						#本地目录
PROJECT_DIR=$LOCAL_DIR/${1}					#工程目录
SHELL=$(readlink -f "$0")					#脚本文件
SHELL_DIR=$(dirname $SHELL)					#脚本路径




API=$(cat $PROJECT_DIR/vendor/build.prop | grep "ro.*build.version.release" | cut -d"=" -f 2)

# Fstab patches
FSTABS="$(find $PROJECT_DIR/vendor/etc -type f \( -name "fstab*" -o -name "*.fstab" \) | sed "s|^./||")"

if [ $API != "" ]; then
	if [ $API -ge 9 ]; then
		sed -i 's/fileencryption=/encryptable=/g' $FSTABS
		sed -i 's/,avb_keys=\/avb\/q-gsi.avbpubkey:\/avb\/r-gsi.avbpubkey:\/avb\/s-gsi.avbpubkey//g' $FSTABS
		sed -i 's/,avb//g' $FSTABS
		sed -i 's/=vbmeta_system//g' $FSTABS
	fi
fi

echo -en "\n完成，任意键返回 ..."
read
