#!/bin/bash

#
#    Copyright (C) 2021 @Errors QQ:1075695713
#    2021-01-01 13:46:06 
#

LOCAL_DIR=$(pwd)						#本地目录
PROJECT_DIR=$LOCAL_DIR/${1}					#工程目录
SHELL=$(readlink -f "$0")					#脚本文件
SHELL_DIR=$(dirname $SHELL)					#脚本路径



echo "本地目录: $LOCAL_DIR"
echo "工程目录: $PROJECT_DIR"
echo "脚本文件: $SHELL"
echo "脚本路径: $SHELL_DIR"

if [ -f $SHELL_DIR/test_add_files.txt ]; then
	echo "cp -ar $SHELL_DIR/test_add_files.txt $PROJECT_DIR/system"
	cp -ar $SHELL_DIR/test_add_files.txt $PROJECT_DIR/system
fi

echo -en "\n完成，任意键返回 ..."
read
