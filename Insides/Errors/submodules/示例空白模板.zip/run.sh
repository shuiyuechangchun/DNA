#!/bin/bash

#
#    Copyright (C) 2021 @Errors QQ:1075695713
#    2021-01-01 13:46:06 
#

LOCAL_DIR=$(pwd)						#本地目录
PROJECT_DIR=$LOCAL_DIR/${1}					#工程目录
SHELL=$(readlink -f "$0")					#脚本文件
SHELL_DIR=$(dirname $SHELL)					#脚本路径

if [[ $(uname -m) == "aarch64" ]]; then
    su=""
    export PATH=$PATH:$SHELL_DIR/Insides/Droid
else
    su="sudo "
    export PATH=$PATH:$SHELL_DIR/Insides/Linux
fi

echo "本地目录: $LOCAL_DIR"
echo "工程目录: $PROJECT_DIR"
echo "脚本文件: $SHELL"
echo "脚本路径: $SHELL_DIR"

echo -en "\n完成，任意键返回 ..."
read
